<?php
	header("HTTP/1.0 404 Not Found");
	$error[]="Упс... файл не найден. 404 извинения";
?>